import asyncio
import json
from pathlib import Path
from io import BytesIO
from pypdf import PdfWriter
from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject
from test_backend import app, client
from backend.answer_guard import safe_answer
from backend.document_service import extract


def answer():
    return dict(language='en',category='housing',summary='Test summary',risk='routine',ready=True,educational=False,known_facts=['The tenant reports a deposit dispute.'],checklist=[dict(item='Deposit receipt',status='unknown',required=True,reason='Shows reported payment.')],questions=['Do you have the receipt?'],practical_steps=['File within 999 days'],legal_information=[dict(text='A made-up entitlement',source_ids=['fake'])],evidence=[],cautions=['Delhi has a deposit limit of one month.'],document_explanation=[],professional_help='Use a consumer forum.')


def test_no_unsupported_legal_cautions_or_actions():
    value=safe_answer(answer(),{'passages':[],'jurisdiction_fallback':True},[],False)
    serialized=json.dumps(value)
    assert '999' not in serialized and 'one month' not in serialized
    assert 'consumer forum' not in serialized
    assert value['legal_information']==[]
    assert not value['ready']


def test_dynamic_checklist_and_gate(app):
    async def fake(owner,context):
        a=answer()
        a['checklist'][0]['item']='Payslip' if 'salary' in context['message'] else 'Deposit receipt'
        a['checklist'][0]['status']='provided' if 'complete' in context['message'] else 'unknown'
        return a
    app.state.ai.answer=fake
    a=client(app)
    first=a.post('/api/cases',json={}).json()['id']
    r=a.post('/api/cases/'+first+'/messages',json={'text':'salary missing','state':'Delhi','event_date':'2026-09-01'}).json()['answer']
    assert r['checklist'][0]['item']=='Payslip' and not r['ready']
    r=a.post('/api/cases/'+first+'/messages',json={'text':'deposit complete','state':'Delhi','event_date':'2026-09-01'}).json()['answer']
    assert r['checklist'][0]['item']=='Deposit receipt' and r['ready']


def test_document_authorization_and_removal(app):
    a,b=client(app),client(app)
    cid=a.post('/api/cases',json={}).json()['id']
    path='/api/cases/'+cid+'/documents'
    headers={'Content-Type':'application/octet-stream','X-Filename':'rental.txt'}
    assert b.post(path,content=b'Private contract',headers=headers).status_code==404
    upload=a.post(path,content=b'Private contract sentinel 55000. Paragraph 4: Deposit will be returned after inspection.',headers=headers)
    assert upload.status_code==200, upload.text
    did=upload.json()['id']
    assert b.delete(path+'/'+did).status_code==404
    assert b'Private contract sentinel' not in app.state.store.path.read_bytes()
    assert len(a.get('/api/cases/'+cid).json()['documents'])==1
    assert a.delete(path+'/'+did).status_code==200
    assert a.get('/api/cases/'+cid).json()['documents']==[]


def test_pdf_extraction():
    writer=PdfWriter()
    page=writer.add_blank_page(width=612,height=792)
    font=DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/Helvetica')})
    page[NameObject('/Resources')]=DictionaryObject({NameObject('/Font'):DictionaryObject({NameObject('/F1'):writer._add_object(font)})})
    stream=DecodedStreamObject();stream.set_data(b'BT /F1 12 Tf 72 720 Td (Fictional agreement: deposit INR 12000.) Tj ET')
    page[NameObject('/Contents')]=writer._add_object(stream)
    out=BytesIO();writer.write(out)
    assert '12000' in extract(out.getvalue(),'sample.pdf')['pages'][0]['text']


def test_historical_and_jurisdiction_filter(app):
    from backend.rag_service import RAGService
    rag=app.state.rag
    with app.state.store.db() as db:
        for ident,state,end in [('delhi','Delhi',None),('karnataka','Karnataka',None),('old','India','2024-06-30')]:
            meta=dict(id=ident,jurisdiction=state,approved_extract=True,effective_to=end)
            db.execute('INSERT INTO sources VALUES (?,?,?,?)',(ident,json.dumps(meta),'deposit evidence','hash'))
            db.execute('INSERT INTO source_fts VALUES (?,?)',(ident,'deposit evidence'))
    result=asyncio.run(rag.retrieve('test','deposit','Delhi','2026-09-27'))
    assert [p['id'] for p in result['passages']]==['delhi']
    assert not result['jurisdiction_fallback']


def test_no_sensitive_data_in_static_files():
    root=Path(__file__).resolve().parents[1]
    for file in (root/'dist').rglob('*'):
        if file.suffix in ('.js','.html','.css'):
            assert 'gsk_' not in file.read_text(encoding='utf-8')


def test_document_fallback_is_original_wording():
    docs=[{'id':'doc:fiction:p1:0','text':'Clause 4: Salary INR 25000.'}]
    a=answer()
    a['document_explanation']=[{'text':'Salary is 99999.','source_ids':['doc:fiction:p1:0']}]
    result=safe_answer(a,{'passages':[],'jurisdiction_fallback':True},docs,False)
    assert '99999' not in json.dumps(result['document_explanation'])
    assert 'Clause 4: Salary INR 25000.' in result['document_explanation'][0]['text']


def test_provider_generation_retry_and_budget(app,monkeypatch):
    import httpx
    ai=app.state.ai
    ai.settings.api_key='fictional-test-key'
    calls=[]
    async def post(self,url,**kwargs):
        calls.append(kwargs['json'])
        payload=({'error':{'code':'json_validate_failed'}} if len(calls)==1 else {'choices':[{'finish_reason':'stop','message':{'content':json.dumps(answer())}}]})
        return httpx.Response(400 if len(calls)==1 else 200,json=payload,request=httpx.Request('POST',url))
    monkeypatch.setattr(httpx.AsyncClient,'post',post)
    result=asyncio.run(ai.answer('synthetic-owner',{'message':'Fictional case'}))
    assert result['category']=='housing' and len(calls)==2


def test_provider_outage_keeps_case_saved(app,monkeypatch):
    import httpx
    app.state.ai.settings.api_key='fictional-test-key'
    app.state.ai.settings.retries=0
    async def fail(self,url,**kwargs):
        raise httpx.ConnectError('Synthetic offline')
    monkeypatch.setattr(httpx.AsyncClient,'post',fail)
    a=client(app)
    cid=a.post('/api/cases',json={}).json()['id']
    result=a.post('/api/cases/'+cid+'/messages',json={'text':'Fictional unpaid salary'}).json()
    assert result['status']=='unavailable'
    assert len(a.get('/api/cases/'+cid).json()['messages'])==2
