"""Opt-in live check using fictional data; incurs a few provider requests."""
import json
import time
from pathlib import Path
import httpx


def main():
    report = []
    with httpx.Client(base_url='http://127.0.0.1:8000', headers={'X-Nyaya-Client':'web'}, timeout=120) as c:
        c.post('/api/session',json={'consent':True}).raise_for_status()
        cid=c.post('/api/cases',json={'title':'Fictional integration check'}).json()['id']
        def ask(text, **kwargs):
            r=c.post(f'/api/cases/{cid}/messages',json={'text':text,**kwargs})
            r.raise_for_status()
            data=r.json()
            assert data['status']=='answered', data.get('message','Unexpected result')
            return data
        result=ask('Fictional test: my employer in Delhi has not paid my August salary. What facts should I collect?',state='Delhi',event_date='2026-09-01')
        assert result['answer']['checklist']
        report.append({'check':'Live employment checklist','passed':True,'items':[x['item'] for x in result['answer']['checklist']]})
        print('Employment checklist passed; pacing the next provider call.', flush=True)
        doc=c.post(f'/api/cases/{cid}/documents',content=b'FICTIONAL EMPLOYMENT AGREEMENT. Clause 4: Monthly salary INR 25000. Payment on the fifth day of the following month. Parties: Example Worker and Example Company. This is a test document.',headers={'X-Filename':'fictional-agreement.txt','Content-Type':'application/octet-stream'})
        doc.raise_for_status()
        time.sleep(60)
        result=ask('What does clause 4 of my uploaded agreement say about payment?')
        assert result['document_sources'] and result['answer']['document_explanation']
        report.append({'check':'Uploaded document question','passed':True,'explanation':result['answer']['document_explanation']})
        print('Document question passed; pacing the Hindi follow-up.', flush=True)
        time.sleep(60)
        result=ask('इसे सरल हिंदी में समझाओ। क्या यह दस्तावेज़ की बात है या कानून का निष्कर्ष?',language='hi')
        assert result['answer']['language']=='hi'
        report.append({'check':'Hindi follow-up','passed':True,'explanation':result['answer']['document_explanation']})
        reopened=c.get(f'/api/cases/{cid}').json()
        assert len(reopened['messages'])==6 and len(reopened['documents'])==1
        report.append({'check':'Saved conversation and document reopen','passed':True})
        # This script creates and removes only its own explicitly fictional case.
        c.delete(f'/api/cases/{cid}').raise_for_status()
    path=Path(__file__).resolve().parents[1]/'rag'/'live-test-report.json'
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps([{'check':x['check'],'passed':x['passed']} for x in report]))


if __name__=='__main__':
    main()
