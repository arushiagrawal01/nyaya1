from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from backend.config import Settings
from backend.main import create_app
from backend.risk_service import assess
from backend.document_service import extract
from backend.legal_update_service import demo_cycle


@pytest.fixture
def app():
    import uuid
    tmp_path=Path(__file__).resolve().parents[1]/'.test-runs'/uuid.uuid4().hex
    tmp_path.mkdir(parents=True)
    (tmp_path / 'dist').mkdir()
    settings = Settings(tmp_path)
    settings.api_key = ''
    return create_app(settings)


def client(app):
    c = TestClient(app, headers={'X-Nyaya-Client': 'web'})
    assert c.post('/api/session', json={'consent': True}).status_code == 200
    return c


def test_isolation_encryption_and_reopen(app):
    a, b = client(app), client(app)
    case = a.post('/api/cases', json={'title': 'Private sentinel XYZ'}).json()
    cid = case['id']
    assert b.get('/api/cases/'+cid).status_code == 404
    assert b.patch('/api/cases/'+cid, json={'title':'stolen','archived':False}).status_code == 404
    assert b.delete('/api/cases/'+cid).status_code == 404
    assert b.post('/api/cases/'+cid+'/messages', json={'text':'hello'}).status_code == 404
    assert b.get('/api/cases').json() == []
    assert b'Private sentinel XYZ' not in app.state.store.path.read_bytes()
    settings = Settings(app.state.store.path.parent.parent)
    reopened = TestClient(create_app(settings), headers={'X-Nyaya-Client':'web'})
    reopened.cookies.update(a.cookies)
    assert reopened.get('/api/cases/'+cid).json()['title'] == 'Private sentinel XYZ'
    assert a.delete('/api/cases/'+cid).status_code == 200
    assert a.get('/api/cases/'+cid).status_code == 404


@pytest.mark.parametrize('text', ['My 12-year-old child was assaulted','मेरे बच्चे को मारा गया','bacche ko dhamki di','He has a gun and will kill me'])
def test_risk_bypasses_ai(app, text):
    a=client(app)
    cid=a.post('/api/cases',json={}).json()['id']
    async def forbidden(*args):
        raise AssertionError('AI must not run')
    app.state.ai.answer=forbidden
    result=a.post('/api/cases/'+cid+'/messages',json={'text':text})
    assert result.status_code==200
    assert result.json()['status']=='escalated'


def test_quota_and_unavailable(app):
    a=client(app)
    cid=a.post('/api/cases',json={}).json()['id']
    result=a.post('/api/cases/'+cid+'/messages',json={'text':'My deposit is not returned.'})
    assert result.status_code==200
    assert result.json()['status']=='unavailable'
    s=app.state.store
    assert s.reserve('test','chat',1,5)
    assert not s.reserve('test','embedding',1,5)


def test_csrf_size_private_paths(app):
    a=client(app)
    assert a.post('/api/cases',json={},headers={'Origin':'https://attacker.invalid'}).status_code==403
    assert a.post('/api/cases',json={'title':'a'*31000}).status_code==413
    assert a.get('/static/.env').status_code==404
    assert a.get('/static/../data/nyaya.sqlite3').status_code==404
    assert a.post('/api/admin/update-demo',json={}).status_code==403


def test_extraction_and_update_history(app):
    assert extract(b'Example rent deposit INR 12000','example.txt')['pages'][0]['text'].endswith('12000')
    with pytest.raises(ValueError): extract(b'not pdf','a.pdf')
    with pytest.raises(ValueError): extract(b'fake','malware.exe')
    with pytest.raises(ValueError): extract(b'\x00binary','a.txt')
    one=demo_cycle(app.state.store)
    two=demo_cycle(app.state.store)
    assert two['previous_hash']==one['hash']
    assert two['version']==2
    with app.state.store.db() as db:
        assert db.execute('SELECT COUNT(*) FROM sources').fetchone()[0]==0


def test_invalid_date(app):
    a=client(app)
    cid=a.post('/api/cases',json={}).json()['id']
    assert a.post('/api/cases/'+cid+'/messages',json={'text':'deposit','event_date':'2026-99-99'}).status_code==422
