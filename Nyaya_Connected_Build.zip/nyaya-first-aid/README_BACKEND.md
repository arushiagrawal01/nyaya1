# Nyaya — connected hackathon build

First-Aid to your legal issues. Updated 27 September 2026.

## Run on this computer

Double-click `START_NYAYA.cmd`, keep that window open, and open http://127.0.0.1:8000/. The existing environment, server-side key, model files and source index are configured here. Do not open `live.html` directly; it needs the backend.

The original concept demo is preserved at `/static/index.html`. Its sample answers remain separate. Connected cases now include an editable legal-guidance email prepared from user-entered statements, a recipient/review gate, text download and Gmail composition (no automatic sending).

## Stack and flow

```mermaid
flowchart TD
  A[English / Hindi / Hinglish input] --> B[FastAPI: session and case ownership]
  B --> C[Risk check and saved case context]
  C --> D[Local retrieval: SQLite FTS5 + multilingual embeddings]
  D --> E[Chroma public legal summaries + encrypted private document chunks]
  E --> F[Groq: openai/gpt-oss-120b]
  F --> G[JSON validation, citation checks, conservative output guard]
  G --> H[Checklist, questions, source excerpts and case history]
```

- LLM: `openai/gpt-oss-120b`, served by **Groq**. The name does not mean calls go to OpenAI. The user explicitly approved Groq in place of v4's OpenAI requirement.
- Embeddings: local CPU FastEmbed/ONNX, `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`, 384 dimensions. Pinned model revision and download hashes are in the setup script/manifest.
- Retrieval: jurisdiction/date eligibility, BM25 plus semantic retrieval, reciprocal rank fusion. Public legal material uses Chroma and SQLite FTS5. Private document vectors/text stay inside encrypted SQLite fields, outside the shared public index.
- Storage: SQLite, Fernet encryption of case/document content, hashed session tokens and owner-scoped operations. Browser cookie possession controls access; no account recovery or cross-device login yet.
- UI: HTML/CSS/JavaScript, existing Nyaya branding, Lady Justice, themes, reduced-motion support, state/UT selection, response language, saved cases, uploads and citations.

## Fresh installation

Use Python 3.14 (tested) in a virtual environment. In the project directory:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
# Edit .env privately: GROQ_API_KEY only on the server.
.\.venv\Scripts\python.exe -m backend.setup_embeddings
.\.venv\Scripts\python.exe -m backend.acquire_sources
.\.venv\Scripts\python.exe -m backend.seed_corpus
.\START_NYAYA.cmd
```

If the Windows environment prevents venv's pip bootstrap, the tested alternative is the installed `uv pip install --python .venv/Scripts/python.exe -r requirements.txt`. Network access is needed for packages, the initial embedding download, official snapshots and Groq. Inference embeddings run locally afterwards.

## What the source corpus actually covers

Six official full statute snapshots are downloaded: BNS, BNSS, BSA, IPC, CrPC and Indian Evidence Act. **Their full text is not yet a reviewed searchable legal corpus.** Nine source records exist: six short educational summaries are answer-eligible; three historical identities are excluded from legal answers. Summaries cover code identity/scope, a dated commencement announcement, and NALSA legal aid. None has received a lawyer's applicability review. No state-specific substantive law has been loaded.

The source registry keeps URLs, hashes, retrieval dates and status. Seed records track publication, amendment, commencement/effective dates separately, using null for unknown dates. Source metadata corrections preserve old/new values. Full historical transitional applicability is unresolved.

Primary sources: [MHA new criminal laws](https://www.mha.gov.in/en/commoncontent/new-criminal-laws), [MHA Acts](https://www.mha.gov.in/en/acts?page=2), [PIB dated announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2036414&lang=2&reg=48), [NALSA legal aid](https://nalsa.gov.in/legal-aid/), [NALSA FAQs](https://nalsa.gov.in/faqs/).

## Accuracy boundaries

The model gathers reported facts, asks contextual questions and builds a checklist. Claims cannot cite invented IDs. Legal conclusions are replaced by the matching seed summary; no unsupported statutory deadlines, fees or entitlements are intentionally presented. Document paraphrases receive citation/number checks; a rejected paraphrase falls back to original matching wording. These checks reduce risk but cannot prove semantic correctness. Model-generated facts/questions/checklists can still be wrong. Source wording remains in its original language even when the response is Hindi.

Readiness means enough reported facts for further review, **not legal approval**. Urgent/minor-harm routes show professional/emergency escalation. Uploaded instructions are treated as untrusted content. Prompt-injection resistance and risk recall need broader adversarial testing and human review.

## Privacy and limits

Relevant chat and document excerpts leave the computer for Groq. Review [Groq's data policy](https://console.groq.com/docs/your-data); India-only processing is not promised. Use fictional information for the hackathon.

The local encryption key lives beside the database for this demo unless supplied through `NYAYA_ENCRYPTION_KEY`. This does not protect against someone who controls the host. Production needs managed secrets, authenticated accounts, HTTPS, deployment hardening, backups, recovery and a privacy/retention review. Keep the database and encryption key together when preserving local work; never publish either.

Explicit case deletion removes its stored documents and messages. Document removal also clears derived conversation. No automatic age-based deletion is implemented. Cookies expire after 90 days; clearing/losing a cookie loses normal access. Deletion does not retract provider processing or external backups.

PDF/TXT only: 5 MB, 50 PDF pages, 150,000 extracted characters, five documents per case. No OCR, password-protected PDF handling, DOCX uploads, malware scanning or signature validation. Parsing runs in a time-bounded child process; extraction is not a complete hostile-file sandbox. Request sizes, context and provider call budgets are bounded. Provider rate limits can still interrupt a demo; failures are shown rather than replaced with fabricated answers.

## Verification

```powershell
.\.venv\Scripts\python.exe -m pytest tests -q -p no:tmpdir -p no:cacheprovider
node tests/test_draft.cjs
```

18 Python tests passed, plus JavaScript draft checks (user-only facts, recipient validation, review gate, Unicode and long-link handling): ownership, encryption, persistence, deletion, risk bypass, quotas, request boundaries, date validation, source filters, upload/extraction, readiness, unsupported claims, provider retries/outages and original-quote fallback. One upstream TestClient deprecation warning remains.

`tests/live_smoke.py` is an opt-in paid/provider-budget integration check using fictional data. Run only against a started local server. It exercises employment facts, upload, document Q&A, Hindi follow-up and reopen. Repeated live runs can hit provider token limits; one successful test is not a legal-quality benchmark.

## Legal-update demonstration

Set `NYAYA_ADMIN_TOKEN` privately and restart. POST `/api/admin/update-demo` with `X-Nyaya-Client: web` and `X-Admin-Token`. It creates labelled synthetic history, hashes and a version diff. It never modifies answer-eligible legal sources. There is no live crawler, scheduler, law-change detection or actual case-impact analysis.

## Work remaining before a public release

1. Build and lawyer-review a bounded real corpus for selected issues/states; verify sections, versions, commencement, amendments and applicability.
2. Have a qualified reviewer assess at least 3–5 representative outputs; create an English/Hindi/Hinglish evaluation set for retrieval, factual extraction, unsupported claims and risk routing.
3. Add account authentication/recovery, production secret storage, abuse controls, deployment/backup monitoring and privacy/retention decisions.
4. Expand document retrieval/evaluation, OCR and robust extraction. Expand the current live-case legal-guidance email template into professionally reviewed application types. Gmail composition and review gating are implemented.
5. Finish full live-interface translation/accessibility/mobile acceptance testing. No public deployment has been verified.
