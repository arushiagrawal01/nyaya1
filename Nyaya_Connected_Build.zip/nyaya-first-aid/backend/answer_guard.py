"""Conservative output boundary: unreviewed prose cannot assert legal rules.

The model extracts case facts/questions. Legal material is rendered as source
excerpts, not uncited interpretations. This deliberately limits the prototype.
"""
import re

RULE = re.compile(r'\b(section|statutory|limitation|legally|illegal|law requires|law says|entitled|mandatory|court fee|deposit limit|notice period|deadline|penalt|punish|must file|consumer forum|consumer.forum)\b|धारा|कानून के अनुसार|अवैध|कानूनी समय|सजा|जुर्माना', re.I)


def safe_answer(result, retrieval, docs, hindi):
    result = dict(result)
    # Facts/questions remain probabilistic extraction, clearly marked as reported.
    result['known_facts'] = [x for x in result['known_facts'] if not RULE.search(x)]
    result['questions'] = [x for x in result['questions'] if not RULE.search(x)][:3]
    checklist = []
    for c in result['checklist'][:12]:
        c = dict(c)
        if RULE.search(c['item']):
            continue
        if RULE.search(c['reason']):
            c['reason'] = 'This helps clarify the facts; it is not a statement of legal requirements.' if not hindi else 'यह तथ्य समझने में सहायक है; यह कानूनी आवश्यकता का दावा नहीं है।'
        if c['status'] == 'verified':
            c['status'] = 'provided'
        checklist.append(c)
    result['checklist'] = checklist
    result['ready'] = bool(result['ready'] and not any(c['required'] and c['status']=='unknown' for c in checklist))
    passages = {p['id']: p for p in retrieval['passages']}
    cited = []
    for claim in result['legal_information']:
        for ident in claim['source_ids']:
            if ident in passages and ident not in cited:
                cited.append(ident)
    # The explanation is the reviewed seed summary itself, with exact provenance.
    result['legal_information'] = [{'text': passages[i]['text'], 'source_ids': [i]} for i in cited]
    document_ids = {d['id']: d['text'] for d in docs}
    doc_claims = []
    for claim in result['document_explanation']:
        ids = claim['source_ids']
        if not ids or not set(ids) <= document_ids.keys():
            continue
        evidence = '\n'.join(document_ids[i] for i in ids)
        numbers = re.findall(r'\d+(?:[.,]\d+)*', claim['text'])
        if all(n in evidence for n in numbers) and not RULE.search(claim['text']):
            doc_claims.append(claim)
    result['document_explanation'] = doc_claims
    if docs and not doc_claims:
        # A failed paraphrase check must not become an invented explanation.
        # Show the matching original wording so the user can inspect it.
        prefix = 'दस्तावेज़ के संबंधित अंश का मूल पाठ (लागू कानून का निष्कर्ष नहीं): ' if hindi else 'Matching document wording (not a conclusion about enforceability): '
        result['document_explanation'] = [{'text': prefix + d['text'][:600], 'source_ids':[d['id']]} for d in docs[:2]]
    result['summary'] = ('नीचे आपकी बताई बातों और उपलब्ध स्रोतों के आधार पर तथ्य जुटाने की योजना है। यह कानूनी निष्कर्ष नहीं है।' if hindi else 'Here is a fact-gathering plan based on what you reported and the available material. It is not a legal conclusion.')
    result['practical_steps'] = ([
        'Keep records you can lawfully access in their original form; do not edit or fabricate evidence.',
        'Write a dated timeline and answer the missing questions you can answer safely.',
        'Ask a qualified legal professional to check applicable law before acting on a filing, fee, notice or deadline.'
    ] if not hindi else [
        'वैध रूप से उपलब्ध रिकॉर्ड मूल रूप में रखें; प्रमाण बदलें या गढ़ें नहीं।',
        'तारीखवार घटनाक्रम लिखें और सुरक्षित रूप से उपलब्ध ज़रूरी तथ्य बताएँ।',
        'शिकायत, शुल्क, नोटिस या समय-सीमा पर कार्रवाई से पहले योग्य पेशेवर से लागू कानून की जाँच कराएँ।'
    ])
    result['evidence'] = [c['item'] for c in checklist if c['status'] != 'not applicable']
    result['cautions'] = ([
        'This is a limited cached corpus. Current law and your individual legal position have not been verified.',
        'Reported facts and document explanations may contain mistakes. Check the original records.',
        'No uncited deadline, fee, statutory entitlement or state-specific rule is established by this response.'
    ] if not hindi else [
        'यह सीमित संग्रह है। मौजूदा कानून और आपके मामले में उसकी लागू स्थिति सत्यापित नहीं है।',
        'बताए गए तथ्यों और दस्तावेज़ की व्याख्या में गलती हो सकती है। मूल रिकॉर्ड जाँचें।',
        'इस उत्तर से बिना स्रोत वाली समय-सीमा, शुल्क, अधिकार या राज्य-विशिष्ट नियम स्थापित नहीं होता।'
    ])
    if retrieval['jurisdiction_fallback']:
        result['cautions'].append('Only central/general material is available; state-specific coverage is missing.' if not hindi else 'केवल केंद्रीय/सामान्य स्रोत उपलब्ध हैं; राज्य-विशिष्ट जानकारी नहीं है।')
    result['professional_help'] = ('Consider a qualified lawyer or ask your District/State Legal Services Authority about free or subsidized legal aid and eligibility. NALSA: https://nalsa.gov.in/' if not hindi else 'योग्य वकील से सलाह लें या मुफ़्त/रियायती सहायता और पात्रता के लिए ज़िला/राज्य विधिक सेवा प्राधिकरण से संपर्क करें। NALSA: https://nalsa.gov.in/')
    return result
