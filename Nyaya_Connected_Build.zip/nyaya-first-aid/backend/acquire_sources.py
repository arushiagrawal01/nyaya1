"""Acquire official source snapshots; no automatic approval of legal applicability."""
import hashlib
import json
from html.parser import HTMLParser
from urllib.parse import urljoin
import httpx
from pypdf import PdfReader
from .config import ROOT
from .store import now


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            href = dict(attrs).get('href', '')
            if href:
                self.links.append(href)


def main():
    target = ROOT / 'rag' / 'originals'
    target.mkdir(parents=True, exist_ok=True)
    sources = [
        ('bns', 'Bharatiya Nyaya Sanhita 2023', 'https://www.mha.gov.in/sites/default/files/2024-04/250883_english_01042024.pdf', 'as_enacted'),
        ('bnss', 'Bharatiya Nagarik Suraksha Sanhita 2023', 'https://www.mha.gov.in/sites/default/files/2024-04/250884_2_english_01042024.pdf', 'as_enacted'),
        ('bsa', 'Bharatiya Sakshya Adhiniyam 2023', 'https://www.mha.gov.in/sites/default/files/2024-04/250882_english_01042024_0.pdf', 'as_enacted'),
        ('crpc', 'Code of Criminal Procedure 1973', 'https://www.mha.gov.in/sites/default/files/2022-09/ccp1973%5B1%5D.pdf', 'historical_unverified_compilation'),
        ('iea', 'Indian Evidence Act 1872', 'https://www.uppolice.gov.in/site/writereaddata/siteContent/acts/202202171236288033TheIndianEvidenceAct1872.pdf', 'historical_unverified_compilation')]
    registry = []
    with httpx.Client(timeout=40, follow_redirects=True) as client:
        parser = Links()
        parser.feed(client.get('https://www.mha.gov.in/en/acts?page=2').text)
        ipc = [x for x in parser.links if 'ipc' in x.lower() and '.pdf' in x.lower()]
        if ipc:
            sources.append(('ipc', 'Indian Penal Code 1860', urljoin('https://www.mha.gov.in', ipc[0]), 'historical_unverified_compilation'))
        for ident, title, url, status in sources:
            record = {'id': ident, 'title': title, 'url': url, 'status': status, 'retrieved_at': now(), 'legal_review': 'pending', 'current_applicability': 'unverified'}
            try:
                path = target / (ident+'.pdf')
                if not path.exists():
                    response = client.get(url)
                    response.raise_for_status()
                    if not response.content.startswith(b'%PDF-'):
                        raise ValueError('Official URL did not return a PDF')
                    path.write_bytes(response.content)
                raw = path.read_bytes()
                record['hash'] = hashlib.sha256(raw).hexdigest()
                reader = PdfReader(path)
                record['pages'] = len(reader.pages)
                # Preserve full original; extraction preview is deliberately not a reviewed legal corpus.
                first = '\n'.join((p.extract_text() or '') for p in reader.pages[:2])
                (target / (ident+'-preview.txt')).write_text(first, encoding='utf-8')
                record['downloaded'] = True
                print(ident, 'downloaded;', len(reader.pages), 'pages')
            except Exception as exc:
                record['downloaded'] = False
                record['error_type'] = type(exc).__name__
                print(ident, 'unavailable:', type(exc).__name__)
            registry.append(record)
    (ROOT / 'rag' / 'source_registry.json').write_text(json.dumps(registry, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
