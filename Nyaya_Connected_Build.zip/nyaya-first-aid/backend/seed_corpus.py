"""Small evidence corpus. Full downloaded statutes remain review candidates."""
import asyncio
import json
from .config import Settings
from .store import Store
from .rag_service import RAGService

RECORDS = [
    ('bns-title', 'Bharatiya Nyaya Sanhita 2023 — commencement mechanism', 'https://www.mha.gov.in/sites/default/files/2024-04/250883_english_01042024.pdf', 'Section 1(1)-(2), PDF page 1', '2023-12-25', 'The Act is named the Bharatiya Nyaya Sanhita, 2023. Section 1(2) states that commencement is by Central Government notification in the Official Gazette, and different dates may be appointed for different provisions. Publication of the Act is not by itself proof that every provision commenced on that date.'),
    ('bnss-title', 'Bharatiya Nagarik Suraksha Sanhita 2023 — subject', 'https://www.mha.gov.in/sites/default/files/2024-04/250884_2_english_01042024.pdf', 'Long title, PDF page 1', '2023-12-25', 'The Bharatiya Nagarik Suraksha Sanhita, 2023 is an Act to consolidate and amend the law relating to Criminal Procedure. This extract establishes the subject of the Act only; it does not establish the procedure applicable to an individual case.'),
    ('bsa-scope', 'Bharatiya Sakshya Adhiniyam 2023 — application', 'https://www.mha.gov.in/sites/default/files/2024-04/250882_english_01042024_0.pdf', 'Section 1(2), PDF page 1', '2023-12-25', 'Section 1(2) of the Bharatiya Sakshya Adhiniyam, 2023 states that it applies to judicial proceedings in or before a Court, including Courts-martial, but not affidavits presented to a Court or officer, nor proceedings before an arbitrator. This as-enacted extract is not a check of subsequent amendments or case applicability.'),
    ('criminal-transition', 'MHA statement on commencement of new criminal laws', 'https://www.pib.gov.in/PressReleasePage.aspx?PRID=2036414&lang=2&reg=48', 'Opening paragraph', '2024-07-24', 'The Ministry of Home Affairs statement reports that BNS, BNSS and BSA provisions came into force from 1 July 2024, except BNS section 106(2) and the entry relating to that provision in the first schedule of BNSS. This is a statement of the position reported in July 2024, not live verification of later changes. Applicability to old conduct or pending proceedings must be separately checked.'),
    ('legal-aid-access', 'NALSA — how to approach legal aid', 'https://nalsa.gov.in/legal-aid/', 'How to apply for free legal aid', None, 'A person seeking free legal services may approach the concerned legal services authority or committee. NALSA describes applications made in writing, using an authority form, or orally with assistance from an officer or paralegal volunteer. Eligibility must be assessed; this is not a guarantee of representation.'),
    ('legal-aid-network', 'NALSA — legal services institutions', 'https://nalsa.gov.in/faqs/', 'Access to legal aid', None, 'NALSA describes access to legal aid through State and District Legal Services Authorities, subject to eligibility under the Legal Services Authorities Act. The appropriate local authority can assess eligibility and available assistance. This source is general referral guidance, not state-specific legal advice.'),
]


async def main():
    settings = Settings()
    records = []
    for ident, title, url, section, publication, text in RECORDS:
        records.append({'id': ident+'-v1', 'title': title, 'act_name': title, 'section': section, 'url': url, 'authority': 'Government of India / NALSA', 'jurisdiction': 'India', 'version': 'snapshot-2026-09-27-v1', 'publication_date': publication, 'amendment_date': None, 'commencement_date': None, 'effective_from': None, 'effective_to': None, 'last_verified': '2026-09-27', 'verification_scope': 'Source text checked, not a legal applicability review', 'status': 'educational excerpt; current applicability unverified', 'approved_extract': True, 'professional_review': False, 'supersedes': None, 'simulation': False, 'text': text})
    registry_path = settings.root/'rag'/'source_registry.json'
    if registry_path.exists():
        registry = json.loads(registry_path.read_text())
        for source in registry:
            if source['downloaded'] and source['id'] in ('ipc','crpc','iea'):
                # Keep historical source lineage in the index, but never use outdated compilations for legal advice.
                records.append({'id': source['id']+'-historical-v1', 'title': source['title'], 'act_name': source['title'], 'section': 'Historical source identity', 'url': source['url'], 'authority': 'Official government archive', 'jurisdiction': 'India', 'version': source['hash'][:12], 'publication_date': None, 'amendment_date': None, 'commencement_date': None, 'effective_from': None, 'effective_to': '2024-06-30', 'last_verified': '2026-09-27', 'verification_scope': 'Download integrity only; historical version unresolved', 'status': 'historical; compilation date and transitional applicability unverified', 'approved_extract': False, 'professional_review': False, 'superseded_by': {'ipc':'BNS','crpc':'BNSS','iea':'BSA'}[source['id']], 'simulation': False, 'text': source['title']+' — historical official compilation. Excluded from legal answers until historical version and transition review. Original SHA-256: '+source['hash']})
    target=settings.root/'rag'/'seed.json'
    target.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    rag=RAGService(settings,Store(settings))
    await rag.ingest('source-setup',records)
    found=await rag.retrieve('source-test','How can I apply for free legal aid?','Delhi','')
    assert any('legal-aid' in p['id'] for p in found['passages']), 'Expected legal aid evidence missing'
    assert found['retrieval_mode']=='hybrid', 'Semantic retrieval not functioning'
    print('Indexed:',len(records),'records. Hybrid retrieval verified. State fallback:',found['jurisdiction_fallback'])


if __name__=='__main__':
    asyncio.run(main())
