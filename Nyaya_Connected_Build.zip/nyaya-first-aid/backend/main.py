import asyncio
from datetime import date
import json
import re
import secrets
from collections import defaultdict
from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from .config import Settings
from .store import Store, now
from .schemas import Message, CaseCreate, CaseEdit, Consent
from .ai_service import AIService, AIUnavailable
from .rag_service import RAGService
from .risk_service import assess, escalation
from .document_service import extract_bounded, context_pages, MAX_BYTES
from .legal_update_service import demo_cycle
from .answer_guard import safe_answer


def create_app(settings=None):
    settings = settings or Settings()
    store = Store(settings)
    app = FastAPI(title='Nyaya', docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=['127.0.0.1', 'localhost', 'testserver'])
    app.state.store = store
    app.state.ai = AIService(settings, store)
    app.state.rag = RAGService(settings, store)
    locks = defaultdict(asyncio.Lock)
    capacity = asyncio.Semaphore(2)

    @app.middleware('http')
    async def boundaries(request, call_next):
        if request.method not in ('GET', 'HEAD', 'OPTIONS'):
            origin = request.headers.get('origin')
            if origin and origin != settings.origin:
                return JSONResponse({'detail': 'Cross-origin request rejected.'}, status_code=403)
            if request.headers.get('x-nyaya-client') != 'web':
                return JSONResponse({'detail': 'Missing request verification header.'}, status_code=403)
            # Reject chunked/unbounded bodies. Uploads also read with a hard bound.
            length = request.headers.get('content-length', '0')
            if not length.isdigit() or int(length) > MAX_BYTES + 20000:
                return JSONResponse({'detail': 'Request is too large or has no declared length.'}, status_code=413)
            limit = MAX_BYTES if request.url.path.endswith('/documents') else 30000
            chunks, received = [], 0
            async for chunk in request.stream():
                received += len(chunk)
                if received > limit:
                    return JSONResponse({'detail': 'Request is too large.'}, status_code=413)
                chunks.append(chunk)
            request._body = b''.join(chunks)
        try:
            result = await call_next(request)
        except Exception:
            result = JSONResponse({'detail': 'The request could not be completed. Please retry.'}, status_code=500)
        result.headers['X-Content-Type-Options'] = 'nosniff'
        result.headers['Referrer-Policy'] = 'no-referrer'
        result.headers['X-Frame-Options'] = 'DENY'
        result.headers['Cache-Control'] = 'no-store'
        result.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
        return result

    def owner(request):
        ident = store.owner(request.cookies.get('nyaya_session', ''))
        if not ident:
            raise HTTPException(401, 'Start a private session first.')
        return ident

    def matter(ident, case_id):
        value = store.get_case(ident, case_id)
        if value is None:
            raise HTTPException(404, 'Case not found.')
        return value

    @app.get('/api/health')
    async def health():
        with store.db() as db:
            count = db.execute('SELECT COUNT(*) FROM sources').fetchone()[0]
        return {'status': 'ok', 'ai_configured': bool(settings.api_key), 'provider': settings.provider, 'model': settings.model, 'source_chunks': count, 'live_source_verification': False, 'ocr': False}

    @app.post('/api/session')
    async def session(body: Consent, request: Request, response: Response):
        existing = store.owner(request.cookies.get('nyaya_session', ''))
        if not existing:
            token = store.session()
            response.set_cookie('nyaya_session', token, httponly=True, samesite='strict', secure=settings.secure_cookie, max_age=60*60*24*90)
        return {'ok': True, 'retention': 'Delete cases whenever needed. Cookie expires after 90 days; keep it to reopen cases.'}

    @app.get('/api/cases')
    async def cases(request: Request):
        return store.list_cases(owner(request))

    @app.post('/api/cases')
    async def new_case(body: CaseCreate, request: Request):
        ident = owner(request)
        if len(store.list_cases(ident)) >= 50:
            raise HTTPException(429, 'Maximum 50 cases per session. Delete an old case first.')
        return store.create_case(ident, body.title.strip() or 'My legal matter')

    @app.get('/api/cases/{case_id}')
    async def get_case(case_id: str, request: Request):
        ident = owner(request)
        value = matter(ident, case_id)
        for m in value['messages']:
            r = m.get('result', {})
            if r.get('status') == 'answered':
                r['answer'] = safe_answer(r['answer'], r, r.get('document_sources', []), r['answer']['language']=='hi')
        return {**value, 'documents': [{'id': d['id'], 'name': d['name'], 'pages': len(d['pages']), 'partial_extraction': d['partial_extraction']} for d in store.documents(ident, case_id)]}

    @app.patch('/api/cases/{case_id}')
    async def edit_case(case_id: str, body: CaseEdit, request: Request):
        ident = owner(request)
        async with locks[case_id]:
            value = matter(ident, case_id)
            value.update(title=body.title.strip() or 'My legal matter', archived=body.archived)
            store.save_case(ident, value)
        return {'ok': True}

    @app.delete('/api/cases/{case_id}')
    async def delete_case(case_id: str, request: Request):
        ident = owner(request)
        async with locks[case_id]:
            matter(ident, case_id)
            with store.db() as db:
                db.execute('DELETE FROM cases WHERE id=? AND owner=?', (case_id, ident))
        return {'deleted': True}

    @app.post('/api/cases/{case_id}/messages')
    async def message(case_id: str, body: Message, request: Request):
        ident = owner(request)
        if not body.text.strip():
            raise HTTPException(422, 'Please describe what happened.')
        if body.event_date:
            try:
                date.fromisoformat(body.event_date)
            except ValueError:
                raise HTTPException(422, 'Use a valid incident date.') from None
        async with locks[case_id], capacity:
            value = matter(ident, case_id)
            if value['archived']:
                raise HTTPException(409, 'Restore this case before continuing.')
            if len(value['messages']) >= 100:
                raise HTTPException(429, 'This case has reached its conversation limit.')
            previous = [{'role': m['role'], 'text': m['text']} for m in value['messages'][-12:] if m['role']=='user']
            value['messages'].append({'role': 'user', 'text': body.text.strip(), 'at': now()})
            value['state'] = body.state or value.get('state', '')
            value['event_date'] = body.event_date or value.get('event_date', '')
            hindi = body.language == 'hi' or bool(re.search(r'[\u0900-\u097f]', body.text))
            risk = assess(body.text) or (value.get('risk_kind') if value.get('risk') else None)
            if risk:
                reply = escalation(risk, hindi)
            else:
                retrieval = await app.state.rag.retrieve(ident, body.text, value['state'], value['event_date'])
                documents = store.documents(ident, case_id)
                vector = None
                if documents:
                    try:
                        vector = (await app.state.rag.embed(ident,[body.text]))[0]
                    except (ValueError, RuntimeError):
                        pass
                docs = context_pages(documents, body.text, query_vector=vector)
                try:
                    result = await app.state.ai.answer(ident, {'today': now()[:10], 'state': value['state'], 'event_date': value['event_date'], 'language': body.language, 'case_summary': value['summary'], 'history': previous, 'message': body.text, 'legal_evidence': retrieval['passages'], 'jurisdiction_fallback': retrieval['jurisdiction_fallback'], 'document_excerpts': docs, 'document_context_is_partial': True})
                    if result['risk'] != 'routine':
                        reply = escalation(result['risk'], hindi)
                    else:
                        legal_ids = {p['id'] for p in retrieval['passages']}
                        doc_ids = {p['id'] for p in docs}
                        result['legal_information'] = [c for c in result['legal_information'] if c['source_ids'] and set(c['source_ids']) <= legal_ids]
                        result['document_explanation'] = [c for c in result['document_explanation'] if c['source_ids'] and set(c['source_ids']) <= doc_ids]
                        for item in result['checklist']:
                            if item['status'] == 'verified':
                                item['status'] = 'provided'
                        missing = any(c['required'] and c['status'] == 'unknown' for c in result['checklist'])
                        result['ready'] = result['ready'] and not missing
                        result['cautions'].append('Sources are a limited cached corpus, not live verification of current law. Professional review may be needed.' if not hindi else 'स्रोत सीमित संग्रह से हैं; मौजूदा कानून की लाइव पुष्टि नहीं हुई है। पेशेवर समीक्षा आवश्यक हो सकती है।')
                        if retrieval['jurisdiction_fallback']:
                            result['cautions'].append('State-specific law is not available for this answer.' if not hindi else 'इस उत्तर के लिए राज्य-विशिष्ट कानून उपलब्ध नहीं है।')
                        result = safe_answer(result, retrieval, docs, hindi)
                        if not result['educational']:
                            for field, title in [('state','State / jurisdiction'),('event_date','Incident date')]:
                                if not value[field]:
                                    result['ready'] = False
                                    result['checklist'].append({'item':title,'status':'unknown','required':True,'reason':'This can change which legal rules apply. Add it above or explain why it is unknown.'})
                        value['summary'] = '; '.join(result['known_facts'])[:4000]
                        value['checklist'] = result['checklist']
                        reply = {'status': 'answered', 'answer': result, **retrieval, 'document_sources': docs}
                except AIUnavailable as exc:
                    reply = {'status': 'unavailable', 'message': str(exc), 'sources': []}
            if reply['status'] == 'escalated':
                value['risk'] = True
                value['risk_kind'] = reply['risk']
            value['messages'].append({'role': 'assistant', 'result': reply, 'at': now()})
            store.save_case(ident, value)
            return reply

    @app.post('/api/cases/{case_id}/documents')
    async def upload(case_id: str, request: Request):
        ident = owner(request)
        async with locks[case_id], capacity:
            value = matter(ident, case_id)
            if value.get('risk'):
                raise HTTPException(409, 'This case needs direct professional help. Please share documents with that professional.')
            if len(store.documents(ident, case_id)) >= 5:
                raise HTTPException(429, 'Maximum five documents per case.')
            raw = await request.body()
            if len(raw) > MAX_BYTES:
                raise HTTPException(413, 'File exceeds 5 MB.')
            try:
                from urllib.parse import unquote
                filename = unquote(request.headers.get('x-filename', 'document.txt'))
                document = await asyncio.to_thread(extract_bounded, raw, filename)
            except ValueError as exc:
                raise HTTPException(422, str(exc)) from None
            chunks = [{'page':p['page'],'offset':i,'text':p['text'][i:i+1000]} for p in document['pages'] for i in range(0,len(p['text']),900)]
            try:
                for i in range(0,len(chunks),16):
                    vectors = await app.state.rag.embed(ident,[c['text'] for c in chunks[i:i+16]])
                    for chunk, vector in zip(chunks[i:i+16],vectors):
                        chunk['vector'] = vector
                document['chunks'] = chunks
                document['retrieval_mode'] = 'local_semantic_and_keyword'
            except (ValueError, RuntimeError):
                document['retrieval_mode'] = 'keyword_only'
            doc_id = store.add_document(ident, case_id, document)
            return {'id': doc_id, 'name': document['name'], 'pages': len(document['pages']), 'partial_extraction': document['partial_extraction']}

    @app.delete('/api/cases/{case_id}/documents/{doc_id}')
    async def remove_document(case_id: str, doc_id: str, request: Request):
        ident = owner(request)
        async with locks[case_id]:
            value = matter(ident, case_id)
            with store.db() as db:
                cursor = db.execute('DELETE FROM documents WHERE id=? AND case_id=? AND owner=?', (doc_id, case_id, ident))
                if not cursor.rowcount:
                    raise HTTPException(404, 'Document not found.')
            # Clear derived conversation, preventing deleted document excerpts remaining in chat memory.
            value.update(messages=[], summary='', checklist=[])
            store.save_case(ident, value)
        return {'deleted': True, 'conversation_cleared': True}

    @app.post('/api/admin/update-demo')
    async def update_demo(request: Request):
        token = request.headers.get('x-admin-token', '')
        if not settings.admin_token or not secrets.compare_digest(token, settings.admin_token):
            raise HTTPException(403, 'Administrator access required.')
        return demo_cycle(store)

    @app.get('/api/sources')
    async def sources():
        with store.db() as db:
            return [json.loads(r['meta']) for r in db.execute('SELECT meta FROM sources')]

    @app.get('/')
    async def index():
        return FileResponse(settings.root / 'dist' / 'live.html')

    # Serve only the public dist directory. Never mount the project root.
    app.mount('/static', StaticFiles(directory=settings.root / 'dist'), name='static')
    return app


app = create_app()
