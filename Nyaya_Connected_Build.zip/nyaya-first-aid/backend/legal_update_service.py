import difflib
import hashlib
import json
from .store import now


def demo_cycle(store):
    # Synthetic content is deliberately outside sources/Chroma so it cannot answer users.
    with store.db() as db:
        previous = db.execute("SELECT detail FROM changes WHERE source_id='DEMO-ONLY' ORDER BY id DESC LIMIT 1").fetchone()
        version = json.loads(previous['detail'])['version'] + 1 if previous else 1
        old = json.loads(previous['detail'])['text'] if previous else 'Synthetic provision: version 0.'
        new = f'Synthetic provision: version {version}. This is not Indian law.'
        event = {'simulation': True, 'version': version, 'text': new, 'hash': hashlib.sha256(new.encode()).hexdigest(), 'previous_hash': hashlib.sha256(old.encode()).hexdigest(), 'diff': '\n'.join(difflib.unified_diff(old.splitlines(), new.splitlines(), fromfile='historical', tofile='new')), 'publication_date': None, 'commencement_date': None, 'effective_date': None, 'case_impact': 'None. Synthetic update, excluded from legal answers.'}
        db.execute('INSERT INTO changes(source_id,created,detail) VALUES (?,?,?)', ('DEMO-ONLY', now(), json.dumps(event)))
    return event
