import asyncio
import hashlib
import json
import re
import httpx
from .store import now


class RAGService:
    def __init__(self, settings, store):
        self.settings, self.store = settings, store
        self._collection = None
        self._embedder = None
        self._embedding_lock = asyncio.Lock()

    @property
    def collection(self):
        if self._collection is None:
            import chromadb
            from chromadb.config import Settings
            client = chromadb.PersistentClient(path=str(self.settings.data / 'chroma'), settings=Settings(anonymized_telemetry=False))
            self._collection = client.get_or_create_collection(self.settings.collection, embedding_function=None, metadata={'embedding_model': self.settings.embed_model})
            if self._collection.metadata.get('embedding_model') != self.settings.embed_model:
                raise ValueError('Embedding model changed; create and rebuild a new collection.')
        return self._collection

    async def embed(self, owner, texts):
        if not texts or len(texts) > 32 or sum(map(len, texts)) > 64000:
            raise ValueError('Embedding batch too large.')
        def run():
            if self._embedder is None:
                from fastembed import TextEmbedding
                path = self.settings.data / 'embedding-model'
                if not (path / 'manifest.json').exists():
                    raise ValueError('Run python -m backend.setup_embeddings first.')
                self._embedder = TextEmbedding(model_name=self.settings.embed_model, specific_model_path=str(path), local_files_only=True, threads=4)
            return [v.tolist() for v in self._embedder.embed(texts)]
        async with self._embedding_lock:
            return await asyncio.to_thread(run)

    async def ingest(self, owner, records):
        # Administrator-approved public source extracts only. No personal documents.
        for offset in range(0, len(records), 16):
            batch = records[offset:offset+16]
            pending = []
            with self.store.db() as db:
                for record in batch:
                    content_hash = hashlib.sha256(record['text'].encode()).hexdigest()
                    record = {**record, 'hash': content_hash}
                    existing = db.execute('SELECT hash,meta FROM sources WHERE id=?', (record['id'],)).fetchone()
                    if existing:
                        if existing['hash'] != content_hash:
                            raise ValueError('Immutable source ID changed. Supply a new version ID.')
                        metadata = json.dumps({k:v for k,v in record.items() if k != 'text'})
                        if json.loads(existing['meta']) != json.loads(metadata):
                            db.execute('INSERT INTO changes(source_id,created,detail) VALUES (?,?,?)', (record['id'], now(), json.dumps({'kind':'metadata_correction','previous':json.loads(existing['meta']),'new':json.loads(metadata)})))
                            db.execute('UPDATE sources SET meta=? WHERE id=?', (metadata, record['id']))
                        continue
                    pending.append(record)
            if not pending:
                continue
            vectors = await self.embed(owner, [r['text'] for r in pending])
            await asyncio.to_thread(self.collection.upsert, ids=[r['id'] for r in pending], embeddings=vectors, documents=[r['text'] for r in pending], metadatas=[{'jurisdiction': r['jurisdiction'], 'version': r['version']} for r in pending])
            with self.store.db() as db:
                for r in pending:
                    db.execute('INSERT INTO sources VALUES (?,?,?,?)', (r['id'], json.dumps({k:v for k,v in r.items() if k != 'text'}), r['text'], r['hash']))
                    db.execute('INSERT INTO source_fts VALUES (?,?)', (r['id'], r['text']))
        return len(records)

    async def retrieve(self, owner, query, state, event_date):
        with self.store.db() as db:
            rows = db.execute('SELECT * FROM sources').fetchall()
        eligible = {}
        for row in rows:
            m = json.loads(row['meta'])
            if m.get('simulation') or not m.get('approved_extract'):
                continue
            if m['jurisdiction'] not in ('India', state):
                continue
            date = event_date or now()[:10]
            if m.get('effective_from') and date < m['effective_from']:
                continue
            if m.get('effective_to') and date > m['effective_to']:
                continue
            if m.get('publication_date') and date < m['publication_date']:
                continue
            eligible[row['id']] = {**m, 'text': row['content']}
        if not eligible:
            return {'passages': [], 'jurisdiction_fallback': True, 'retrieval_mode': 'no_coverage'}
        terms = re.findall(r'\w+', query)[:30]
        lexical = []
        if terms:
            with self.store.db() as db:
                lexical = [r[0] for r in db.execute('SELECT id FROM source_fts WHERE source_fts MATCH ? ORDER BY bm25(source_fts) LIMIT 200', (' OR '.join('"'+t+'"' for t in terms),)) if r[0] in eligible][:20]
        semantic, mode = [], 'keyword_only'
        try:
            vector = (await self.embed(owner, [query[:6000]]))[0]
            result = await asyncio.to_thread(self.collection.query, query_embeddings=[vector], ids=list(eligible), n_results=min(20, len(eligible)))
            semantic = result['ids'][0]
            mode = 'hybrid'
        except (ValueError, RuntimeError, TypeError):
            pass
        scores = {}
        for ranking in (lexical, semantic):
            for i, ident in enumerate(ranking):
                scores[ident] = scores.get(ident, 0) + 1/(60+i+1)
        ids = sorted(scores, key=scores.get, reverse=True)[:5]
        passages = [eligible[i] for i in ids]
        return {'passages': passages, 'jurisdiction_fallback': not any(p['jurisdiction'] == state and state for p in passages), 'retrieval_mode': mode}
