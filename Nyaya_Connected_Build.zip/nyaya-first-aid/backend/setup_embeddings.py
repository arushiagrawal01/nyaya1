"""Download pinned public embedding artifacts; no credential is used."""
import hashlib
import json
from pathlib import Path
import httpx
from .config import ROOT

REVISION = 'faf4aa4225822f3bc6376869cb1164e8e3feedd0'
REPO = 'qdrant/paraphrase-multilingual-MiniLM-L12-v2-onnx-Q'
FILES = ['config.json', 'model_optimized.onnx', 'special_tokens_map.json', 'tokenizer.json', 'tokenizer_config.json']


def main():
    target = ROOT / 'data' / 'embedding-model'
    target.mkdir(parents=True, exist_ok=True)
    checksums = {}
    with httpx.Client(timeout=120, follow_redirects=True) as client:
        for name in FILES:
            path = target / name
            if not path.exists():
                temporary = path.with_suffix(path.suffix+'.part')
                with client.stream('GET', f'https://huggingface.co/{REPO}/resolve/{REVISION}/{name}') as response:
                    response.raise_for_status()
                    with temporary.open('wb') as out:
                        for block in response.iter_bytes():
                            out.write(block)
                temporary.replace(path)
            checksums[name] = hashlib.sha256(path.read_bytes()).hexdigest()
            print('Ready:', name)
    (target / 'manifest.json').write_text(json.dumps({'repository': REPO, 'revision': REVISION, 'sha256': checksums}, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
