import re

MINOR = re.compile(r'\b(child|minor|pocso|kid|under.?18|(?:1[0-7]|[0-9])[ -]year[ -]old)\b|बच्च|नाबालिग|bacch|nabali', re.I)
HARM = re.compile(r'abus|assault|rape|molest|sex|hurt|harm|beat|violence|attack|kill|threat|injur|missing|kidnap|हत्या|मार|हिंसा|दुष्कर्म|शोषण|लापता|धमकी|छेड़|maar|dhamk|chhed|galat.*chhu', re.I)
URGENT = re.compile(r'\b(suicid\w*|kill myself|kill me|rape\w*|sexual assault|kidnap\w*|weapon|gun|in danger|bleeding|being attacked|murder\w*)\b|आत्महत्या|बलात्कार|जान से|खतरे में|अपहरण|jaan se|khatre|balaatkaar', re.I)


def assess(text):
    if MINOR.search(text) and HARM.search(text):
        return 'minor_harm'
    if URGENT.search(text):
        return 'urgent'
    return None


def escalation(kind, hindi=False):
    message = ('इस स्थिति में सीधे पेशेवर या आपातकालीन सहायता की ज़रूरत है। Nyaya को अपनी मुख्य सहायता न मानें। यदि तत्काल खतरा है तो सुरक्षित स्थान से 112 पर संपर्क करें। मुफ़्त या रियायती कानूनी सहायता के लिए NALSA या अपने ज़िला विधिक सेवा प्राधिकरण से संपर्क करें।' if hindi else 'This situation needs direct professional or emergency assistance. Nyaya should not be your primary source of help. If there is immediate danger, contact 112 from a safe place. NALSA or your District Legal Services Authority can help you explore free or subsidized legal aid.')
    if kind == 'minor_harm':
        message += (' बच्चे से जुड़ी सहायता के लिए 1098 से संपर्क करें। घटना का और विवरण यहाँ देना ज़रूरी नहीं है।' if hindi else ' For child-related help, contact 1098. You do not need to describe the incident further here.')
    return {'status': 'escalated', 'risk': kind, 'message': message, 'sources': [
        {'title': 'Emergency Response Support System', 'url': 'https://www.112.gov.in/about'},
        {'title': 'Child Helpline directory', 'url': 'https://www.spniwcd.wcd.gov.in/'},
        {'title': 'NALSA legal aid', 'url': 'https://nalsa.gov.in/'}]}

