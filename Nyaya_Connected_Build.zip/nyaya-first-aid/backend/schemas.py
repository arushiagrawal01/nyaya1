from typing import Literal
from pydantic import BaseModel, ConfigDict, Field


class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid')


class Check(Strict):
    item: str
    status: Literal['unknown', 'provided', 'verified', 'not applicable']
    required: bool
    reason: str


class Claim(Strict):
    text: str
    source_ids: list[str]


class Answer(Strict):
    language: Literal['en', 'hi', 'hinglish']
    category: str
    summary: str
    risk: Literal['routine', 'urgent', 'minor_harm']
    ready: bool
    educational: bool
    known_facts: list[str]
    checklist: list[Check]
    questions: list[str]
    practical_steps: list[str]
    legal_information: list[Claim]
    evidence: list[str]
    cautions: list[str]
    document_explanation: list[Claim]
    professional_help: str


class Message(Strict):
    text: str = Field(min_length=1, max_length=6000)
    state: str = Field(default='', max_length=80)
    event_date: str = Field(default='', max_length=10, pattern=r'^(\d{4}-\d{2}-\d{2})?$')
    language: Literal['auto', 'en', 'hi'] = 'auto'


class CaseCreate(Strict):
    title: str = Field(default='My legal matter', min_length=1, max_length=120)


class CaseEdit(Strict):
    title: str = Field(min_length=1, max_length=120)
    archived: bool


class Consent(Strict):
    consent: Literal[True]
