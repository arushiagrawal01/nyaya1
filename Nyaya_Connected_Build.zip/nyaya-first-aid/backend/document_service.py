from io import BytesIO
import re
from pypdf import PdfReader

MAX_BYTES = 5 * 1024 * 1024


def extract(raw, filename):
    if not raw or len(raw) > MAX_BYTES:
        raise ValueError('Use a nonempty PDF or text file up to 5 MB.')
    name = re.sub(r'[^\w. ()-]', '_', filename or 'document')[-100:]
    if name.lower().endswith('.pdf'):
        if not raw.startswith(b'%PDF-'):
            raise ValueError('This is not a valid PDF file.')
        reader = PdfReader(BytesIO(raw), strict=True)
        if reader.is_encrypted:
            raise ValueError('Password-protected PDFs are not supported. Upload an unlocked copy you are authorized to use.')
        if len(reader.pages) > 50:
            raise ValueError('Use a PDF of 50 pages or fewer.')
        pages = [{'page': i+1, 'text': (page.extract_text() or '')} for i, page in enumerate(reader.pages)]
    elif name.lower().endswith('.txt'):
        try:
            text = raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            raise ValueError('Text files must use UTF-8 encoding.') from None
        if '\x00' in text:
            raise ValueError('Binary content is not supported as text.')
        pages = [{'page': 1, 'text': text}]
    else:
        raise ValueError('Currently supported: text-based PDF and UTF-8 .txt. Image/scanned-document OCR is not implemented.')
    if not any(p['text'].strip() for p in pages):
        raise ValueError('No readable text found. Scanned-document OCR is not available yet.')
    if sum(len(p['text']) for p in pages) > 150000:
        raise ValueError('Document text is too long. Upload a smaller relevant extract.')
    return {'name': name, 'pages': pages, 'partial_extraction': any(not p['text'].strip() for p in pages)}


def worker(raw, filename, connection):
    try:
        connection.send({'ok': extract(raw, filename)})
    except Exception:
        connection.send({'error': 'Could not read this file. Use a text-based PDF (50 pages maximum) or UTF-8 text, up to 5 MB. Scans and encrypted PDFs are unsupported.'})
    finally:
        connection.close()


def extract_bounded(raw, filename):
    # Anonymous standard pipes work on Windows without named-pipe permissions.
    # communicate kills/reaps a stuck parser; document bytes never use temp files.
    import subprocess
    import sys
    import json
    proc = subprocess.Popen([sys.executable, '-m', 'backend.document_service', filename],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    try:
        output, _ = proc.communicate(raw, timeout=15)
        if proc.returncode:
            raise ValueError('Could not process this document. Try a smaller text-based file.')
        value = json.loads(output)
        if 'error' in value:
            raise ValueError(value['error'])
        return value['ok']
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.communicate()
        raise ValueError('Document processing timed out. Try a smaller extract.') from None


def context_pages(documents, query, budget=12000, query_vector=None):
    terms = set(re.findall(r'\w+', query.lower()))
    passages = []
    for doc in documents:
        chunks = doc.get('chunks') or [{'page':page['page'],'offset':offset,'text':page['text'][offset:offset+1000]} for page in doc['pages'] for offset in range(0,len(page['text']),900)]
        for chunk in chunks:
            text = chunk['text']
            score = sum(term in text.lower() for term in terms if len(term) > 2)
            if query_vector is not None and chunk.get('vector'):
                import numpy as np
                score += 10*float(np.dot(query_vector,chunk['vector']))
            passages.append((score, {'id': f"doc:{doc['id']}:p{chunk['page']}:{chunk['offset']}", 'title': doc['name'], 'page': chunk['page'], 'text': text}))
    selected, used = [], 0
    for _, passage in sorted(passages, key=lambda x: -x[0]):
        if used + len(passage['text']) > budget:
            continue
        selected.append(passage)
        used += len(passage['text'])
    return selected


if __name__ == '__main__':
    import sys
    import json
    try:
        result = {'ok': extract(sys.stdin.buffer.read(MAX_BYTES + 1), sys.argv[1])}
    except Exception:
        result = {'error': 'Could not read this file. Use a text-based PDF (50 pages maximum) or UTF-8 text, up to 5 MB. Scans and encrypted PDFs are unsupported.'}
    sys.stdout.buffer.write(json.dumps(result, ensure_ascii=True).encode('utf-8'))
