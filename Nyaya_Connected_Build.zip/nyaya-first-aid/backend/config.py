from pathlib import Path
import os
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[1]


class Settings:
    def __init__(self, root=ROOT):
        self.root = Path(root)
        values = {**dotenv_values(self.root / '.env'), **os.environ}
        self.provider = values.get('AI_PROVIDER', 'groq')
        if self.provider not in ('groq', 'openai'):
            raise ValueError('Unsupported configured provider')
        self.api_key = values.get('GROQ_API_KEY' if self.provider == 'groq' else 'OPENAI_API_KEY', '') or ''
        self.model = values.get('AI_MODEL', 'openai/gpt-oss-120b' if self.provider == 'groq' else 'gpt-4o-mini')
        self.api_url = 'https://api.groq.com/openai/v1/chat/completions' if self.provider == 'groq' else 'https://api.openai.com/v1/chat/completions'
        self.embed_model = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'
        self.timeout = min(60, max(5, float(values.get('AI_TIMEOUT_SECONDS', 30))))
        self.retries = min(2, max(0, int(values.get('AI_MAX_RETRIES', 2))))
        self.daily_cap = min(100, max(1, int(values.get('AI_MAX_CALLS_PER_SESSION_DAY', 20))))
        self.global_cap = min(1000, max(1, int(values.get('AI_GLOBAL_CALLS_PER_DAY', 100))))
        self.data = self.root / 'data'
        self.data.mkdir(exist_ok=True, parents=True)
        self.encryption_key = values.get('NYAYA_ENCRYPTION_KEY') or ''
        self.admin_token = values.get('NYAYA_ADMIN_TOKEN') or ''
        self.secure_cookie = values.get('NYAYA_HTTPS', 'false').lower() == 'true'
        self.origin = values.get('NYAYA_ORIGIN', 'http://127.0.0.1:8000').rstrip('/')
        self.collection = values.get('RAG_COLLECTION', 'nyaya_legal_v1')
