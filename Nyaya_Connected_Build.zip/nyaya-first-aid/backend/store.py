import hashlib
import json
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from cryptography.fernet import Fernet


def now():
    return datetime.now(timezone.utc).isoformat()


class Store:
    def __init__(self, settings):
        self.path = settings.data / 'nyaya.sqlite3'
        key_path = settings.data / '.encryption-key'
        if settings.encryption_key:
            key = settings.encryption_key.encode()
        elif key_path.exists():
            key = key_path.read_bytes()
        else:
            if self.path.exists():
                raise RuntimeError('Encryption key missing. Restore the original key; refusing to replace it.')
            key = Fernet.generate_key()
            with key_path.open('xb') as target:
                target.write(key)
        self.cipher = Fernet(key)
        with self.db() as db:
            db.executescript('''
            PRAGMA journal_mode=DELETE;
            CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, created TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS cases(id TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES sessions(id), content BLOB NOT NULL, updated TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY, owner TEXT NOT NULL, case_id TEXT NOT NULL REFERENCES cases(id) ON DELETE CASCADE, content BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS usage(owner TEXT, day TEXT, kind TEXT, calls INTEGER NOT NULL, tokens INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(owner,day,kind));
            CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY, meta TEXT NOT NULL, content TEXT NOT NULL, hash TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY, source_id TEXT, created TEXT, detail TEXT);
            CREATE VIRTUAL TABLE IF NOT EXISTS source_fts USING fts5(id UNINDEXED, content);
            ''')

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('PRAGMA secure_delete=ON')
        try:
            yield db
            db.commit()
        finally:
            db.close()

    def pack(self, value):
        return self.cipher.encrypt(json.dumps(value, ensure_ascii=False).encode())

    def unpack(self, value):
        return json.loads(self.cipher.decrypt(value))

    def session(self):
        token = secrets.token_urlsafe(32)
        owner = hashlib.sha256(token.encode()).hexdigest()
        with self.db() as db:
            db.execute('INSERT INTO sessions VALUES (?,?)', (owner, now()))
        return token

    def owner(self, token):
        owner = hashlib.sha256(token.encode()).hexdigest()
        with self.db() as db:
            row = db.execute('SELECT id FROM sessions WHERE id=?', (owner,)).fetchone()
        return owner if row else None

    def create_case(self, owner, title):
        value = {'id': secrets.token_hex(16), 'title': title, 'archived': False, 'messages': [], 'checklist': [], 'summary': '', 'risk': False}
        with self.db() as db:
            db.execute('INSERT INTO cases VALUES (?,?,?,?)', (value['id'], owner, self.pack(value), now()))
        return value

    def get_case(self, owner, case_id):
        with self.db() as db:
            row = db.execute('SELECT content FROM cases WHERE id=? AND owner=?', (case_id, owner)).fetchone()
        return self.unpack(row['content']) if row else None

    def save_case(self, owner, value):
        with self.db() as db:
            db.execute('UPDATE cases SET content=?,updated=? WHERE id=? AND owner=?', (self.pack(value), now(), value['id'], owner))

    def list_cases(self, owner):
        with self.db() as db:
            rows = db.execute('SELECT content,updated FROM cases WHERE owner=? ORDER BY updated DESC', (owner,)).fetchall()
        return [dict(id=(v := self.unpack(r['content']))['id'], title=v['title'], archived=v['archived'], updated=r['updated']) for r in rows]

    def reserve(self, owner, kind, limit, global_limit):
        day = now()[:10]
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            count = db.execute('SELECT COALESCE(SUM(calls),0) FROM usage WHERE owner=? AND day=?', (owner, day)).fetchone()[0]
            total = db.execute('SELECT COALESCE(SUM(calls),0) FROM usage WHERE day=?', (day,)).fetchone()[0]
            if count >= limit or total >= global_limit:
                return False
            db.execute('INSERT INTO usage(owner,day,kind,calls) VALUES (?,?,?,1) ON CONFLICT(owner,day,kind) DO UPDATE SET calls=calls+1', (owner, day, kind))
        return True

    def tokens(self, owner, kind, tokens):
        with self.db() as db:
            db.execute('UPDATE usage SET tokens=tokens+? WHERE owner=? AND day=? AND kind=?', (tokens, owner, now()[:10], kind))

    def add_document(self, owner, case_id, document):
        doc_id = secrets.token_hex(16)
        with self.db() as db:
            db.execute('INSERT INTO documents VALUES (?,?,?,?)', (doc_id, owner, case_id, self.pack(document)))
        return doc_id

    def documents(self, owner, case_id):
        with self.db() as db:
            rows = db.execute('SELECT id,content FROM documents WHERE owner=? AND case_id=?', (owner, case_id)).fetchall()
        return [dict(id=r['id'], **self.unpack(r['content'])) for r in rows]

