# Nyaya

**Connected build, 27 September 2026:** run `START_NYAYA.cmd` and open http://127.0.0.1:8000/. See [README_BACKEND.md](README_BACKEND.md) for the Groq/local-embedding backend, setup, tests and limitations. The sections below document the preserved historical concept demo, not the connected backend.

## Original bilingual concept demo

Tagline: **First-Aid to your legal issues**.

Open `dist/index.html` with its neighboring files, or use the standalone `Nyaya_First_Aid_Demo.html` supplied in outputs. No installation or key is needed. Gmail and official resource links require internet.

Walkthrough: choose English or Hindi, load the salary example, select the work/incident state, explore the example, explain the fictional letter, and prepare a template. Edit it, enter a recipient, review the message, and choose Open in Gmail. Gmail never sends automatically; add attachments there. Long drafts use copy/paste as a fallback.

All 28 states and 8 union territories are selectable. State and optional district are kept as context; legal applicability is not determined. The app links to NALSA's state-authority directory rather than inventing state-specific legal rules. Location and personal details are not stored persistently. Only theme and language preferences use localStorage.

Both themes support reduced-motion preferences. The Hindi interface includes sample explanations, notices, forms, and draft templates. Switching languages preserves user edits rather than translating or replacing them. Regenerating a draft requires confirmation.

The API connection view is future setup only: provider/model selection and an empty-key configuration template. A real key must go into a server-side environment or secret store. The disabled browser field intentionally does not accept or store credentials. No live inference or backend is implemented by this update.

This is a static concept prototype. It has no live AI, PDF upload, legal retrieval, or backend. It rejects arbitrary problem descriptions rather than pretending to analyze them. Inputs remain in page memory. Reload to clear demo state. Use fictional information.

The complete project brief is supplied separately as `NYAYA_PROJECT.md` in the outputs folder. The earlier PDF remains a historical progress snapshot.

Sources consulted for the selector and resource routing: https://www.india.gov.in/explore-india and https://nalsa.gov.in/ . Resource links are not claim-level legal citations.

Lady Justice artwork: generated using the built-in image generation tool; saved as `dist/assets/lady-justice.png`. Prompt: one dignified blindfolded Lady Justice holding balanced scales, ivory and restrained bronze sculpture, midnight navy background and warm gold lighting, portrait composition with scales visible, no text, logos or UI. The scales brand mark is a simple inline SVG.
